"use strict";

const recruitArt={
  bedroom:{bg:"assets/room-bedroom.webp"},garden:{bg:"assets/room-garden.webp"},
  lab:{bg:"assets/prologue/cell.webp",crop:[0,0,221,145],tone:"cold"},
  dark:{bg:"assets/prologue/cell.webp",crop:[0,0,185,115],tone:"blackout"},
  night:{bg:"assets/room-garden.webp",tone:"night"},
  library:{bg:"assets/room-library.webp"},street:{bg:"assets/room-street.webp",tone:"night"},
  parlour:{bg:"assets/room-ballroom.webp"},study:{bg:"assets/manor.webp"},
  field:{bg:"assets/room-field.webp"},london:{bg:"assets/room-street.webp"}
};
const recruitProps={tea:"assets/goods-tea.webp"};
const recruitCast={
  ciel:"assets/ciel.png",ciel11:"assets/ciel-11.webp",ciel12:"assets/ciel-12.webp",seb:"assets/sebastian.webp",
  finny:"assets/npc-finny.webp",mey:"assets/npc-mey.webp",bard:"assets/npc-bard.webp",tanaka:"assets/npc-tanaka.webp",
  snake:"assets/npc-snake.webp",soma:"assets/npc-soma.webp",agni:"assets/npc-agni.webp"
};
// Speakers before the naming scene use the boy's number. His gardener portrait appears only at the manor.
const recruitScenes={
  gardener:{name:"피니안",title:"번호 대신 이름을",result:"피니안이 팬텀하이브가의 정원사가 되었다.",scenes:[
    {title:"연구소",art:"lab",lines:[
      ["연구원","여긴 끝났어. 기록부터 없애!"],["다른 연구원","아이들은요?"],["연구원","실험체도 남겨 둘 수 없어. 서둘러!"],
      ["S-012","위가 시끄럽다. 옆에 앉아 있던 아이가 먼저 고개를 들었다."]]},
    {title:"선생님",art:"dark",lines:[
      ["아이","선생님?"],["S-012","문이 열렸다. 묻고 싶은 게 있었는데, 바로 옆에서 소리가 났다."],
      ["S-012","방금까지 내 옆에 앉아 있었잖아. 선생님, 왜……?"],["S-012","정신을 차렸을 때 나는 맨발로 달리고 있었다. 사다리 위의 뚜껑을 밀었다."]]},
    {title:"달빛 아래",art:"night",cast:["ciel","seb"],lines:[
      ["S-012","밖이었다. 하늘에 둥근 빛이 떠 있었다. 바로 앞에 두 사람이 서 있었다."],["S-012","으아아……!"],
      ["세바스찬","도련님, 제 뒤로."],["시엘","잠깐, 세바스찬."],["시엘","네 이름은?"],["피니안의 회상","그때는 무슨 말인지 몰랐다. 내게 이름을 물은 사람은 도련님이 처음이었다."]]},
    {title:"그 뒤, 저택의 서재",art:"library",cast:["finny","ciel"],lines:[
      ["피니안의 회상","머리카락이 이만큼 자랐을 때였다. 도련님이 책 한 권을 꺼내셨다."],["시엘","너한테 이름을 하나 지어 주겠어."],
      ["소년","이름?"],["시엘","언제까지고 널 피험자 12번이라 부를 순 없잖아. 금발이 제법 근사하게 자랐군."]]},
    {title:"금발의 영웅",art:"library",cast:["finny","ciel"],lines:[
      ["시엘","‘핀’. 옛말로 금발을 뜻하지. 여기 나오는 영웅도 그 머리 때문에 그렇게 불렸어."],["소년","그 책에 나처럼 머리 노란 사람이 있어?"],
      ["시엘","그래. 그래서 네 이름은 피니언이다."]]},
    {title:"세바스찬의 한마디",art:"library",cast:["ciel","seb"],lines:[
      ["세바스찬","꽤 거창한 이름을 골라 주셨군요."],["세바스찬","제 경우처럼 개 이름을 물려받는 것보다는 낫겠습니다만."]]},
    {title:"소년의 책",art:"library",cast:["finny","ciel"],lines:[
      ["시엘","이 책은 네 거야. 글자를 익히면 네 이름이 나온 대목을 직접 읽어 봐. 알았지, 피니언?"],["피니안","응!"],
      ["피니안의 회상","나한테 준 첫 책이었다. 꼭 안았더니 팔 안에서 표지가 우그러졌다."]]},
    {title:"저택의 새 사용인",art:"library",cast:["finny","seb"],lines:[
      ["세바스찬","이제야 표정이 풀리는군요."],["세바스찬","그럼 그 책을 조금만 놓아 주시겠습니까. 말씨도, 힘을 쓰는 법도 차차 익히셔야겠군요."]]}
  ]},
  maid:{name:"메이린",title:"아침의 올빼미",result:"메이린이 팬텀하이브가의 메이드로 합류했다.",scenes:[
    {"title": "아침 시중", "art": "bedroom", "cast": ["seb"], "lines": [["세바스찬", "도련님. 아침입니다."], ["시엘", "으음……."], ["장면", "세바스찬이 커튼을 걷었다. 햇빛이 이불 끝까지 들어왔다."]], "music": "daily"},
    {"title": "깨진 창", "art": "bedroom", "cast": ["seb"], "lines": [["장면", "창이 깨졌다. 시엘이 몸을 일으키기도 전에 은제 찻주전자가 그의 앞을 가로막았다."], ["올빼미", "빗나갔어……?"], ["시엘", "뭐야? 이건 또 왜 새는 거야?"], ["장면", "세바스찬이 찻잔을 받쳐 들었다. 주전자 옆구리에서 새는 홍차가 잔 안으로 떨어졌다."]]},
    {"title": "닐기리", "art": "bedroom", "cast": ["seb", "ciel"], "lines": [["세바스찬", "오늘 아침 차는 닐기리로 골랐습니다."], ["시엘", "차 이름을 물어봤어? 방금 내 머리 옆을 지나간 게 뭐냐고!"], ["세바스찬", "누가 도련님을 쏘았습니다. 제법 눈이 좋은 손님이군요."], ["세바스찬", "피니. 잠깐 이쪽으로 와 주시겠습니까?"]], "prop": "tea"},
    {"title": "식사가 식기 전에", "art": "garden", "cast": ["ciel", "seb"], "lines": [["장면", "정원에 아침상이 차려졌다. 세바스찬이 시엘의 의자를 당겼다."], ["세바스찬", "완두콩 수프와 미트볼입니다. 크루아상은 방금 구웠고, 달걀도 삶아 두었습니다."], ["세바스찬", "후식은 오렌지 젤리입니다. 그럼 다녀오겠습니다. 천천히 드십시오."], ["시엘", "……어?"]], "music": "daily"},
    {"title": "창가의 올빼미", "art": "library", "cast": ["seb", "ciel"], "lines": [["세바스찬", "실례하겠습니다, 도련님. 아침에 찾아온 ‘올빼미’를 데려왔습니다."], ["올빼미", "저 애가…… 팬텀하이브 백작?"], ["시엘", "청방의 백이 나를 노린다더니. 자기가 길렀다는 올빼미까지 보낸 걸 보면 정보가 맞았군."], ["올빼미", "날 죽여. 뭘 물어봐도 대답은 못 들어. 바닥만 더러워질 거야."], ["세바스찬", "바닥까지 다시 닦을 일을 왜 만들겠습니까? 저는 다른 용건이 있습니다."]]},
    {"title": "뜻밖의 일자리", "art": "library", "cast": ["seb", "ciel"], "lines": [["세바스찬", "팬텀하이브가에서 일해 보실 생각은 없습니까?"], ["올빼미", "……뭐?"], ["시엘", "뭐라고? 세바스찬, 저 사람은 오늘 아침에 나를 쏘러 왔어!"], ["세바스찬", "예. 그런데 저희는 사람이 모자라고, 피니 혼자서 저택 일을 전부 맡을 수도 없지요. 저 눈이라면 망을 보는 데도 쓸모가 있겠습니다."], ["세바스찬", "게다가 일을 그르친 이상 백에게 돌아갈 수도 없겠지요. 이곳에는 빈자리가 있습니다."]]},
    {"title": "빈자리는 메이드", "art": "library", "cast": ["ciel", "seb"], "lines": [["세바스찬", "손님을 맞으려면 메이드 한 명은 있어야 한다고 하신 분은 도련님이셨습니다."], ["시엘", "메이드? 잠깐. 올빼미가……?"], ["세바스찬", "예. 이분은 여성입니다만."], ["시엘", "……그렇다고 날 죽이러 온 사람한테 앞치마를 주겠다는 거야?"]]},
    {"title": "저택이 찾는 사람", "art": "library", "cast": ["seb", "ciel"], "lines": [["세바스찬", "도련님을 지킬 솜씨가 있고, 배신할 수 없는 처지에 있고, 도련님이 직접 그 실력을 보신 사람. 구인 광고를 내도 좀처럼 찾기 힘들겠지요."], ["올빼미", "잠깐. 둘이서 멋대로 정하지 마. 난 안 해. 사람을 죽이던 손으로 메이드 일을 어떻게 하라고."], ["세바스찬", "먼지떨이를 들어 보기도 전에 그걸 어떻게 아십니까? 주인에게 성가신 것을 치운다는 점에선 익숙한 일일 텐데요."], ["세바스찬", "소개장도 여권도 없이 청방에 쫓기면서, 이 문을 나가면 어디로 가실 생각입니까?"], ["올빼미", "그건……."]]},
    {"title": "고용 조건", "art": "library", "cast": ["seb"], "lines": [["세바스찬", "메이드 경력은 묻지 않습니다. 나이도, 어디에서 오셨는지도요."], ["세바스찬", "급료와 휴일이 있고, 설탕과 홍차도 넉넉히 드립니다. 일을 잘하시면 급료는 올라갑니다."], ["세바스찬", "어떻습니까? 첫 일자리치고는 괜찮은 조건이지요."]], "music": "daily"},
    {"title": "그 눈동자", "art": "library", "cast": ["ciel", "seb"], "lines": [["장면", "세바스찬이 올빼미 앞에 몸을 낮췄다. 그의 어깨 너머, 창가에 어린 백작이 서 있었다."], ["세바스찬", "그 눈동자―, 도련님을 위해 써보지 않겠습니까?"]], "music": "daily"}
  ]},
  cook:{name:"바르도",title:"저택의 새 셰프",result:"바르도가 팬텀하이브가의 셰프로 합류했다.",scenes:[
    {title:"서재 면담",art:"library",cast:["ciel","seb"],lines:[
      ["시엘","미군 출신을 우리 집 셰프로 쓰겠다고?"],
      ["세바스찬","네, 도련님."],
      ["시엘","꼭 둬야 해? 지금까지 주방은 너 혼자서도 잘 꾸려 왔잖아."],
      ["세바스찬","손님은 저녁상에 오른 요리로도 그 집을 평합니다. 팬텀하이브가의 이름을 다시 세우시려면 셰프가 필요합니다."]]},
    {title:"요리와 출신",art:"library",cast:["ciel","bard"],lines:[
      ["시엘","이름이 알려진 셰프라면 대개 프랑스나 이탈리아 사람이잖아."],
      ["바르도","양키라서 마음에 안 드나? 프랑스 사람이 구우면 같은 고기도 더 고상한 맛이 난다 이거야?"],
      ["바르도","어차피 배에 들어가면 그만인데, 맛이 무슨 대수라고."],
      ["시엘","……난 누가 요리하든 상관없어. 식탁에 올릴 거면 맛있는 게 좋다는 거지."]]},
    {title:"주방의 명령",art:"library",cast:["ciel","bard"],lines:[
      ["시엘","전장에선 숯이 될 때까지 구우라는 명령을 받았을지도 모르지."],
      ["시엘","내 주방에선 태우지 마. 이건 명령이야."],
      ["장면","바르도가 고개를 들었다."]]},
    {title:"교육을 맡기다",art:"library",cast:["ciel","seb"],lines:[
      ["세바스찬","애초에 제가 이분을 데려온 건 요리 솜씨를 보아서가 아닙니다. 이만한 저택에 상급 사용인이 저 하나일 수는 없으니까요."],
      ["시엘","방식은 너한테 맡길게. 제대로 교육시켜."],
      ["세바스찬","알겠습니다."]]}
  ]},
  homecoming:{name:"타나카",title:"돌아온 집사",result:"타나카가 휴직을 마치고 저택 서재로 돌아왔다.",scenes:[
    {title:"다시 찾은 서재",art:"library",cast:["tanaka","ciel"],lines:[
      ["장면","서재 문을 두드리는 소리에 시엘이 펜을 놓았다. 문 앞에 선 타나카가 모자를 벗었다."],
      ["타나카","다녀왔습니다, 도련님. 오래 자리를 비웠습니다."],
      ["시엘","어서 와, 할아범. 앉아. 할아범한테 직접 묻고 싶은 게 있었어."],
      ["시엘","그날 아버지를 해친 자 말이야. 할아범은 얼굴을 봤어?"],
      ["타나카","……아니요, 도련님. 저도 보지 못했습니다."],
      ["시엘","……그렇구나."],
      ["타나카","주인어른을 지켜 드리지 못하고 다시 이 방에 들어서려니, 면목이 없습니다."],
      ["시엘","할아범 잘못이 아니야."],
      ["장면","시엘이 책상 한쪽에 쌓아 둔 편지를 타나카 앞으로 밀었다."],
      ["시엘","돌아오면 맡기려고 남겨 뒀어. 예전처럼 할아범이 먼저 봐 줘."]]},
    {title:"집사장의 회중시계",art:"library",cast:["tanaka","seb"],lines:[
      ["타나카","예, 도련님. 그 전에…… 세바스찬 씨, 잠시 손을 펴 주시겠습니까?"],
      ["장면","타나카가 조끼에서 회중시계를 꺼내 세바스찬의 흰 장갑 위에 놓았다. 뚜껑에는 팬텀하이브가의 문장이 새겨져 있었다."],
      ["세바스찬","이 시계를 제게 주시는 겁니까?"],
      ["타나카","이 집의 집사장이 대대로 물려받는 시계입니다. 이제 세바스찬 씨가 차 주셨으면 합니다."],
      ["타나카","제가 아직 당신이 어떤 분인지는 잘 모릅니다만…… 도련님을 잘 부탁드립니다."],
      ["세바스찬","……예. 팬텀하이브가의 집사로서 최선을 다해 도련님을 모시겠습니다."]]}
  ]},
  circus:{name:"스네이크",title:"천막에 남은 편지",result:"스네이크가 뱀들과 함께 저택에 머물며 풋맨으로 일하게 되었다.",scenes:[
    {title:"공연이 끝난 자리",art:"field",cast:["snake"],lines:[
      ["장면","스코틀랜드 야드가 노아의 방주 서커스단 단원들을 연행했다. 스네이크가 돌아왔을 때는 빈 마차의 계단에 편지 한 통만 놓여 있었다."],
      ["스네이크","내 이름이야. 봐, 에밀리. 조커가 쓸 때는 꼭 끝 글자가 저렇게 기울잖아."],
      ["편지","스네이크. 우리가 내일 아침까지 돌아오지 않으면 팬텀하이브 백작을 찾아가."],
      ["스네이크","……백작이 데려가게 한 거야? 그러니까 이 사람을 찾아가라고 한 거지?"]]},
    {title:"백작을 찾아온 손님",art:"library",cast:["snake","ciel"],lines:[
      ["스네이크","우리 식구들을 돌려줘. ……라고 오스카가 말해."],
      ["시엘","내가 누굴 데리고 있다는 거야?"],
      ["장면","스네이크가 접힌 편지를 내밀었다. 시엘은 마지막 줄까지 읽고 봉투째 돌려주었다."],
      ["스네이크","야드가 다 데려갔어. 그런데 여기 적힌 이름은 당신 하나잖아."],
      ["시엘","내가 시켰다면 네게 내 이름을 남길 이유가 있겠어? 이건 네가 도움을 청할 곳을 적어 준 거야."],
      ["스네이크","……그럼 여기엔 아무도 없어?"],
      ["시엘","그래. 단원들은 아직 야드에 있어. 면회가 가능한지는 알아봐 줄 수 있어."]]},
    {title:"현관의 첫 손님",art:"parlour",cast:["snake","seb"],lines:[
      ["장면","스네이크가 돌아서다가 현관문을 열었다. 문밖에서 우편배달부가 막 손을 들어 노크하려던 참이었다."],
      ["세바스찬","벌써 들으셨습니까? 제게 온 우편이군요. 감사합니다."],
      ["스네이크","에밀리가 계단에 누가 있다고 했어."],
      ["세바스찬","그렇다면 도련님께 풋맨을 한 명 구했다고 말씀드려도 되겠습니까? 손님을 맞고, 누가 왔는지 알려 주는 일입니다."]]},
    {title:"스네이크의 대답",art:"parlour",cast:["snake","ciel"],lines:[
      ["시엘","면회 답장은 이 집으로 오게 할게. 기다리는 동안 일해 볼 생각은 있어?"],
      ["스네이크","여기서 지내려면…… 얘들도 같이 있어야 해."],
      ["시엘","그럼 네가 하나씩 소개해. 내 손님이 먼저 놀라는 일은 없게."],
      ["스네이크","이쪽은 에밀리. 그리고 난 스네이크야. ……풋맨 일, 할게. 이건 내가 하는 말이야."]]}
  ]},
  visitPrince:{name:"소마·아그니",title:"런던 집의 두 손님",result:"소마와 아그니가 런던 타운하우스에 함께 입주했다.",scenes:[
    {title:"새 열쇠",art:"london",cast:["ciel","seb"],lines:[
      ["장면","시엘이 런던 집의 새 열쇠를 자물쇠에 꽂았다. 등 뒤에서 찻잔 부딪치는 소리가 났다."],
      ["소마","시엘! 문 좀 열어 다오. 아그니가 손이 모자라단 말이다!"]]},
    {title:"문턱 위의 짐",art:"london",cast:["soma","agni"],lines:[
      ["장면","아그니는 한 팔에 상자 두 개를 받치고, 다른 손에 작은 주전자를 들고 있었다. 소마가 들고 있는 건 자기 찻잔 하나였다."],
      ["아그니","새집의 첫 차는 직접 대접하시겠다기에요. 전하, 잔을 조금만 수평으로 들어 주십시오."],
      ["소마","그래서 안 흘렸잖느냐. 자, 네 잔도 있다, 시엘."]]},
    {title:"응접실에서",art:"parlour",cast:["soma","ciel"],lines:[
      ["시엘","찻잔은 고마워. 그런데 차 한 잔 마시러 오면서 트렁크는 왜 가져왔지?"],
      ["소마","네가 영지에 있으면 이 집은 누가 보느냐? 우리가 런던에 머무는 동안 맡으면 되잖아."],
      ["시엘","내가 없을 때 온 편지는 뜯지 말고 모아 둬. 손님이 오면 이름을 적어 놓고."],
      ["소마","그럼 네가 올 때마다 내 손님이기도 하겠군. 오늘이 그 첫날이다. 앉아라!"]]},
    {title:"두 사람의 방",art:"parlour",cast:["soma","agni"],lines:[
      ["아그니","저도 전하 곁에 머물러도 되겠습니까? 런던으로 오는 서신은 제가 챙기겠습니다."],
      ["시엘","위층에 방이 둘이야. 어느 쪽을 쓸지는 둘이 정해."],
      ["소마","들었느냐, 아그니? 먼저 차부터 마시자. 짐은 내가 같이 옮길 테니."],
      ["아그니","예, 소마 님. 그럼 오늘은 제 잔도 하나 꺼내겠습니다."]]}
  ]}
};
for(const book of Object.values(recruitScenes)){
  book.lines=book.scenes.flatMap((scene,i)=>scene.lines.map(([speaker,text])=>({scene,i,speaker,text})));
}
function pageAt(id,at){return Number.isInteger(at)?Math.min(Math.max(0,at),recruitScenes[id].lines.length-1):0;}
function recruitPage(id){return pageAt(id,state.recruitPage?.id===id?state.recruitPage.at:0);}
function observePortraitStage(stage){
  const observer=new ResizeObserver(([entry])=>{
    stage.style.setProperty("--portrait-scene-height",entry.contentRect.height+"px");
    stage.style.setProperty("--portrait-scene-width",entry.contentRect.width+"px");
  });
  observer.observe(stage);
}
function cielPortraitScale(age){return String(Math.min(152,140+6*(age-10))/186);}
function sceneStanding(name,side,src,extra=""){
  return '<img class="butler cast cast-'+side+'" alt="'+name+'" '+extra+'src="'+src+'">';
}
function sceneLine(speaker,text,next,attributes="",heading=""){
  return '<article class="dialogue" '+attributes+'>'+(speaker?'<small>'+speaker+'</small>':'')+heading+
    '<p>'+text+' '+next+'</p></article>';
}
const recruitNames={ciel:"시엘",seb:"세바스찬",finny:"피니안",mey:"메이린",bard:"바르도",tanaka:"타나카",snake:"스네이크",soma:"소마",agni:"아그니"};
function recruitMarkup(id,at,file=x=>x,readOnly=false,auto=false,answers=""){
  const book=recruitScenes[id],{scene,speaker,text}=book.lines[at];
  const art=recruitArt[scene.art],bg=file(art.bg),last=at===book.lines.length-1;
  const backdrop=art.crop
    ? '<svg class="review-room recruit-backdrop '+art.tone+'" viewBox="'+art.crop.join(" ")+'" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><image width="680" height="380" href="'+bg+'"/></svg>'
    : '<div class="review-room '+(art.tone||'')+'" style="background-image:url(&quot;'+bg+'&quot;)"></div>';
  const cast=scene.cast||[];
  const actors=cast.map((person,i)=>{
    const side=person==="ciel"?"right":cast.includes("ciel")||i===0?"left":"right";
    return sceneStanding(recruitNames[person],side,file(recruitCast[person]));
  }).join("");
  const label=last?(readOnly?"회상 마치기":"영입 확정"):"다음 대사";
  const arrow=answers?'':'<button type="button" class="line-next" data-read="'+(last?'finish':'next')+'" aria-label="'+label+'">▼</button>';
  const controls='<div class="opening-top recruit-controls" role="group" aria-label="대사 재생">'+
    '<button type="button" data-read="previous" '+(at===0?'disabled':'')+'>이전</button>'+
    '<button type="button" data-read="auto" aria-pressed="'+auto+'" '+(last?'disabled':'')+'>'+(auto?'자동 멈춤':'자동 재생')+'</button>'+
    '<button type="button" data-read="skip" '+(last?'disabled':'')+'>건너뛰기</button></div>';
  const props=scene.prop?'<img class="recruit-tea" alt="닐기리 홍차" src="'+file(recruitProps[scene.prop])+'">':'';
  return backdrop+actors+props+sceneLine(speaker==="장면"?"":speaker,text,arrow,
    'data-book="'+id+'" data-leaf="'+at+'" aria-live="polite" aria-atomic="true"')+answers+controls;
}
let recruitTimer=0,recruitAuto=false;
function stopRecruitAuto(){clearTimeout(recruitTimer);recruitTimer=0;recruitAuto=false;}
function drawRecruitReader(host,id,at,file,readOnly,onPage,onFinish,answers=""){
  const end=recruitScenes[id].lines.length-1;
  clearTimeout(recruitTimer);if(at===end)stopRecruitAuto();
  host.innerHTML=recruitMarkup(id,at,file,readOnly,recruitAuto,answers);
  const line=host.querySelector(".dialogue"),bar=host.querySelector(".recruit-controls");
  function step(to){if(line.isConnected)onPage(to);}
  function arm(){
    if(!recruitAuto||at===end)return;
    const delay=Math.min(6200,1700+recruitScenes[id].lines[at].text.length*90);
    recruitTimer=setTimeout(()=>{if(line.isConnected&&!document.hidden)step(at+1);else stopRecruitAuto();},delay);
  }
  function click(e){
    const control=e.target.closest("[data-read]");
    if(!line.isConnected||control?.disabled||window.getSelection()?.toString())return;
    const read=control?.dataset.read||(e.currentTarget===line?(at===end?"finish":"next"):"");
    if(!read)return;e.stopPropagation();
    if(read==="auto"){
      if(recruitAuto)stopRecruitAuto();else{recruitAuto=true;arm();}
      control.textContent=recruitAuto?"자동 멈춤":"자동 재생";control.setAttribute("aria-pressed",String(recruitAuto));return;
    }
    stopRecruitAuto();
    if(read==="previous"&&at>0)step(at-1);
    if(read==="next"&&at<end)step(at+1);
    if(read==="skip"&&at<end)step(end);
    if(read==="finish"&&at===end&&!answers)onFinish();
  }
  function keydown(e){
    if(e.altKey||e.ctrlKey||e.metaKey||e.repeat||!["ArrowLeft","ArrowRight"].includes(e.key))return;
    e.preventDefault();e.stopPropagation();stopRecruitAuto();
    const to=at+(e.key==="ArrowLeft"?-1:1);
    if(to>=0&&to<=end)step(to);
  }
  for(const element of [line,bar]){
    element.addEventListener("keydown",keydown);
    element.addEventListener("click",click);
  }
  arm();
}
function showMonthlyRecruit(host,event){
  const id=event.id,at=recruitPage(id);
  const current=()=>tab==="plan"&&["event","slotEvent"].includes(state.phase)&&state.pending===id&&recruitPage(id)===at;
  const hasChoices=at===recruitScenes[id].lines.length-1&&event.choices.length>1;
  const answers=hasChoices?'<div class="answers" role="group" aria-label="대화 선택지">'+
    event.choices.map((c,i)=>btn(c.label,"choose:"+i,Boolean(c.when&&!c.when(state)),"vn-choice")).join("")+'</div>':"";
  host.hidden=false;drawRecruitReader(host,id,at,recruitArtwork(id,state.month),false,to=>{
    if(!current())return;state.recruitPage={id,at:to,...(id==="maid"||id==="cook"?{version:2}:{})};persist();render();
    host.querySelector(".line-next, .answers button")?.focus({preventScroll:true});
  },()=>{if(current())choose(0)},answers);
}
function recruitAge(id,month){return id==="gardener"?10:ageAt(month,28);}
function recruitArtwork(id,month){
  const age=recruitAge(id,month);
  return path=>path===recruitCast.ciel&&age>=11?(age>=12?recruitCast.ciel12:recruitCast.ciel11):path;
}
let recruitMemory=null;
function openRecruitMemory(id){
  if(!Object.hasOwn(recruitScenes,id))return;stopRecruitAuto();
  const month=state.events.find(entry=>entry.id===id)?.month||state.month;
  recruitMemory={id,at:0,month};tab="staffMemory";render(true);
}
function closeRecruitMemory(){
  stopRecruitAuto();const id=recruitMemory?.id;recruitMemory=null;tab="record";render();
  const button=document.querySelector('[data-action="recruit-memory:'+id+'"]');
  if(button){button.closest("details").open=true;button.focus({preventScroll:true});}
}
function showRecruitMemory(host){
  const memory=recruitMemory,{id,at,month}=memory;
  host.hidden=false;host.dataset.review="false";
  drawRecruitReader(host,id,at,recruitArtwork(id,month),true,to=>{
    if(tab!=="staffMemory"||memory!==recruitMemory)return;
    memory.at=to;render();host.querySelector(".line-next")?.focus({preventScroll:true});
  },closeRecruitMemory);
}
