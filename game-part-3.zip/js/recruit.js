"use strict";

const recruitArt={
  bedroom:{bg:"assets/room-bedroom.webp"},garden:{bg:"assets/room-garden.webp"},
  lab:{bg:"assets/prologue/cell.webp",crop:[0,0,221,145],tone:"cold"},
  dark:{bg:"assets/prologue/cell.webp",crop:[0,0,185,115],tone:"blackout"},
  night:{bg:"assets/room-garden.webp",tone:"night"},
  library:{bg:"assets/room-library.webp"},street:{bg:"assets/room-street.webp",tone:"night"},
  parlour:{bg:"assets/room-ballroom.webp"},study:{bg:"assets/manor.webp"}
};
const recruitProps={tea:"assets/goods-tea.webp"};
const recruitCast={
  ciel:"assets/ciel.png",ciel11:"assets/ciel-11.webp",ciel12:"assets/ciel-12.webp",seb:"assets/sebastian.webp",
  finny:"assets/npc-finny.webp",mey:"assets/npc-mey.webp"
};
// Speakers before the naming scene use the boy's number. His gardener portrait appears only at the manor.
const recruitScenes={
  gardener:{name:"피니안",title:"번호 대신 이름을",result:"피니안이 팬텀하이브가의 정원사가 되었다.",scenes:[
    {title:"연구소",art:"lab",lines:[
      ["연구원","여긴 끝났어. 기록부터 없애!"],["다른 연구원","아이들은요?"],["연구원","실험체도 남겨 둘 수 없어. 서둘러!"],
      ["S-012","위가 시끄럽다. 옆에 앉아 있던 아이가 먼저 고개를 들었다."]]},
    {title:"선생님",art:"dark",lines:[
      ["아이","선생님?"],["S-012","문이 열렸다. 묻고 싶은 게 있었는데, 바로 옆에서 소리가 났다."],
      ["S-012","방금까지 내 옆에 앉아 있었잖아. 선생님, 왜……?"],["S-012","정신을 차렸을 때 나는 맨발로 달리고 있었다. 사다리 위의 뚜껑을 밀었다."]]},
    {title:"달빛 아래",art:"night",cast:["ciel","seb"],lines:[
      ["S-012","밖이었다. 하늘에 둥근 빛이 떠 있었다. 바로 앞에 두 사람이 서 있었다."],["S-012","으아아……!"],
      ["세바스찬","도련님, 제 뒤로."],["시엘","잠깐, 세바스찬."],["시엘","네 이름은?"],["피니안의 회상","그때는 무슨 말인지 몰랐다. 내게 이름을 물은 사람은 도련님이 처음이었다."]]},
    {title:"그 뒤, 저택의 서재",art:"library",cast:["finny","ciel"],lines:[
      ["피니안의 회상","머리카락이 이만큼 자랐을 때였다. 도련님이 책 한 권을 꺼내셨다."],["시엘","너한테 이름을 하나 지어 주겠어."],
      ["소년","이름?"],["시엘","언제까지고 널 피험자 12번이라 부를 순 없잖아. 금발이 제법 근사하게 자랐군."]]},
    {title:"금발의 영웅",art:"library",cast:["finny","ciel"],lines:[
      ["시엘","‘핀’. 옛말로 금발을 뜻하지. 여기 나오는 영웅도 그 머리 때문에 그렇게 불렸어."],["소년","그 책에 나처럼 머리 노란 사람이 있어?"],
      ["시엘","그래. 그래서 네 이름은 피니언이다."]]},
    {title:"세바스찬의 한마디",art:"library",cast:["ciel","seb"],lines:[
      ["세바스찬","꽤 거창한 이름을 골라 주셨군요."],["세바스찬","제 경우처럼 개 이름을 물려받는 것보다는 낫겠습니다만."]]},
    {title:"소년의 책",art:"library",cast:["finny","ciel"],lines:[
      ["시엘","이 책은 네 거야. 글자를 익히면 네 이름이 나온 대목을 직접 읽어 봐. 알았지, 피니언?"],["피니안","응!"],
      ["피니안의 회상","나한테 준 첫 책이었다. 꼭 안았더니 팔 안에서 표지가 우그러졌다."]]},
    {title:"저택의 새 사용인",art:"library",cast:["finny","seb"],lines:[
      ["세바스찬","이제야 표정이 풀리는군요."],["세바스찬","그럼 그 책을 조금만 놓아 주시겠습니까. 말씨도, 힘을 쓰는 법도 차차 익히셔야겠군요."]]}
  ]},
  maid:{name:"메이린",title:"아침의 올빼미",result:"메이린이 팬텀하이브가의 메이드로 합류했다.",scenes:[
    {"title": "아침 시중", "art": "bedroom", "cast": ["seb"], "lines": [["세바스찬", "도련님. 아침입니다."], ["시엘", "으음……."], ["장면", "세바스찬이 커튼을 걷었다. 햇빛이 이불 끝까지 들어왔다."]], "music": "daily"},
    {"title": "깨진 창", "art": "bedroom", "cast": ["seb"], "lines": [["장면", "창이 깨졌다. 시엘이 몸을 일으키기도 전에 은제 찻주전자가 그의 앞을 가로막았다."], ["올빼미", "빗나갔어……?"], ["시엘", "뭐야? 이건 또 왜 새는 거야?"], ["장면", "세바스찬이 찻잔을 받쳐 들었다. 주전자 옆구리에서 새는 홍차가 잔 안으로 떨어졌다."]]},
    {"title": "닐기리", "art": "bedroom", "cast": ["seb", "ciel"], "lines": [["세바스찬", "오늘 아침 차는 닐기리로 골랐습니다."], ["시엘", "차 이름을 물어봤어? 방금 내 머리 옆을 지나간 게 뭐냐고!"], ["세바스찬", "누가 도련님을 쏘았습니다. 제법 눈이 좋은 손님이군요."], ["세바스찬", "피니. 잠깐 이쪽으로 와 주시겠습니까?"]], "prop": "tea"},
    {"title": "식사가 식기 전에", "art": "garden", "cast": ["ciel", "seb"], "lines": [["장면", "정원에 아침상이 차려졌다. 세바스찬이 시엘의 의자를 당겼다."], ["세바스찬", "완두콩 수프와 미트볼입니다. 크루아상은 방금 구웠고, 달걀도 삶아 두었습니다."], ["세바스찬", "후식은 오렌지 젤리입니다. 그럼 다녀오겠습니다. 천천히 드십시오."], ["시엘", "……어?"]], "music": "daily"},
    {"title": "창가의 올빼미", "art": "library", "cast": ["seb", "ciel"], "lines": [["세바스찬", "실례하겠습니다, 도련님. 아침에 찾아온 ‘올빼미’를 데려왔습니다."], ["올빼미", "저 애가…… 팬텀하이브 백작?"], ["시엘", "청방의 백이 나를 노린다더니. 자기가 길렀다는 올빼미까지 보낸 걸 보면 정보가 맞았군."], ["올빼미", "날 죽여. 뭘 물어봐도 대답은 못 들어. 바닥만 더러워질 거야."], ["세바스찬", "바닥까지 다시 닦을 일을 왜 만들겠습니까? 저는 다른 용건이 있습니다."]]},
    {"title": "뜻밖의 일자리", "art": "library", "cast": ["seb", "ciel"], "lines": [["세바스찬", "팬텀하이브가에서 일해 보실 생각은 없습니까?"], ["올빼미", "……뭐?"], ["시엘", "뭐라고? 세바스찬, 저 사람은 오늘 아침에 나를 쏘러 왔어!"], ["세바스찬", "예. 그런데 저희는 사람이 모자라고, 피니 혼자서 저택 일을 전부 맡을 수도 없지요. 저 눈이라면 망을 보는 데도 쓸모가 있겠습니다."], ["세바스찬", "게다가 일을 그르친 이상 백에게 돌아갈 수도 없겠지요. 이곳에는 빈자리가 있습니다."]]},
    {"title": "빈자리는 메이드", "art": "library", "cast": ["ciel", "seb"], "lines": [["세바스찬", "손님을 맞으려면 메이드 한 명은 있어야 한다고 하신 분은 도련님이셨습니다."], ["시엘", "메이드? 잠깐. 올빼미가……?"], ["세바스찬", "예. 이분은 여성입니다만."], ["시엘", "……그렇다고 날 죽이러 온 사람한테 앞치마를 주겠다는 거야?"]]},
    {"title": "저택이 찾는 사람", "art": "library", "cast": ["seb", "ciel"], "lines": [["세바스찬", "도련님을 지킬 솜씨가 있고, 배신할 수 없는 처지에 있고, 도련님이 직접 그 실력을 보신 사람. 구인 광고를 내도 좀처럼 찾기 힘들겠지요."], ["올빼미", "잠깐. 둘이서 멋대로 정하지 마. 난 안 해. 사람을 죽이던 손으로 메이드 일을 어떻게 하라고."], ["세바스찬", "먼지떨이를 들어 보기도 전에 그걸 어떻게 아십니까? 주인에게 성가신 것을 치운다는 점에선 익숙한 일일 텐데요."], ["세바스찬", "소개장도 여권도 없이 청방에 쫓기면서, 이 문을 나가면 어디로 가실 생각입니까?"], ["올빼미", "그건……."]]},
    {"title": "고용 조건", "art": "library", "cast": ["seb"], "lines": [["세바스찬", "메이드 경력은 묻지 않습니다. 나이도, 어디에서 오셨는지도요."], ["세바스찬", "급료와 휴일이 있고, 설탕과 홍차도 넉넉히 드립니다. 일을 잘하시면 급료는 올라갑니다."], ["세바스찬", "어떻습니까? 첫 일자리치고는 괜찮은 조건이지요."]], "music": "daily"},
    {"title": "그 눈동자", "art": "library", "cast": ["ciel", "seb"], "lines": [["장면", "세바스찬이 올빼미 앞에 몸을 낮췄다. 그의 어깨 너머, 창가에 어린 백작이 서 있었다."], ["세바스찬", "그 눈동자―, 도련님을 위해 써보지 않겠습니까?"]], "music": "daily"}
  ]}
};
for(const book of Object.values(recruitScenes)){
  book.lines=book.scenes.flatMap((scene,i)=>scene.lines.map(([speaker,text])=>({scene,i,speaker,text})));
}
function pageAt(id,at){return Number.isInteger(at)?Math.min(Math.max(0,at),recruitScenes[id].lines.length-1):0;}
function recruitPage(id){return pageAt(id,state.recruitPage?.id===id?state.recruitPage.at:0);}
function recruitMarkup(id,at,file=x=>x,readOnly=false,auto=false){
  const book=recruitScenes[id],{scene,speaker,text}=book.lines[at],art=recruitArt[scene.art],bg=file(art.bg),last=at===book.lines.length-1;
  const still=art.crop?'<svg class="recruit-still" viewBox="'+art.crop.join(" ")+'" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><image width="680" height="380" href="'+bg+'"/></svg>':'<img class="recruit-still" alt="" src="'+bg+'">';
  const names={ciel:"시엘",ciel11:"시엘",seb:"세바스찬",finny:"피니안",mey:"메이린"};
  const cast=(scene.cast||[]).map((person,i)=>'<img class="recruit-actor pos-'+i+(speaker===names[person]?' speaking':'')+'" src="'+file(recruitCast[person])+'" alt="'+names[person]+'">').join("");
  return '<article class="recruit-reader '+(art.tone||'')+'" data-book="'+id+'" data-leaf="'+at+'">'+still+'<div class="recruit-cast">'+cast+(scene.prop?'<img class="recruit-tea" alt="닐기리 홍차" src="'+file(recruitProps[scene.prop])+'">':'')+'</div><div class="opening-mat recruit-mat"><header class="opening-top"><button type="button" data-read="previous" '+(at===0?'disabled':'')+'>이전</button><button type="button" data-read="auto" aria-pressed="'+auto+'">'+(auto?'자동 멈춤':'자동 재생')+'</button></header><div class="opening-transcript recruit-transcript"><div class="opening-caption"><small>'+book.name+' 영입</small><span>'+scene.title+'</span></div><div class="opening-voice" aria-live="polite" aria-atomic="true"><b>'+speaker+'</b><p>'+text+'</p></div><div class="opening-controls"><small>'+(at+1)+' / '+book.lines.length+'</small><button type="button" data-read="'+(last?'finish':'next')+'">'+(last?(readOnly?'회상 마치기':'영입 기록하기'):'다음 ▸')+'</button></div></div></div></article>';
}
let recruitTimer=0,recruitAuto=false;
function stopRecruitAuto(){clearTimeout(recruitTimer);recruitTimer=0;recruitAuto=false;}
function drawRecruitReader(host,id,at,file,readOnly,onPage,onFinish){
  clearTimeout(recruitTimer);if(at===recruitScenes[id].lines.length-1)stopRecruitAuto();host.innerHTML=recruitMarkup(id,at,file,readOnly,recruitAuto);
  const node=host.querySelector(".recruit-reader"),last=at===recruitScenes[id].lines.length-1;
  function step(to){
    if(!node.isConnected)return;
    clearTimeout(recruitTimer);onPage(to);
  }
  function arm(){
    if(!recruitAuto||last)return;
    const delay=Math.min(6200,1700+recruitScenes[id].lines[at].text.length*90);
    recruitTimer=setTimeout(()=>{if(node.isConnected&&!document.hidden)step(at+1);else stopRecruitAuto()},delay);
  }
  node.addEventListener("click",e=>{
    const control=e.target.closest("[data-read]");
    if(control?.disabled||window.getSelection()?.toString())return;
    const read=control?.dataset.read||(!last?"next":"");
    if(!read)return;e.stopPropagation();
    if(read==="auto"){if(recruitAuto)stopRecruitAuto();else{recruitAuto=true;arm()}control.textContent=recruitAuto?"자동 멈춤":"자동 재생";control.setAttribute("aria-pressed",String(recruitAuto));return;}
    stopRecruitAuto();
    if(read==="previous"&&at>0)step(at-1);
    if(read==="next"&&!last)step(at+1);
    if(read==="finish"&&last)onFinish();
  });
  if(last)stopRecruitAuto();else arm();
}
function showMonthlyRecruit(host,event){
  const id=event.id,at=recruitPage(id);
  const current=()=>tab==="plan"&&["event","slotEvent"].includes(state.phase)&&state.pending===id&&recruitPage(id)===at;
  host.hidden=false;drawRecruitReader(host,id,at,recruitArtwork(id,state.month),false,to=>{
    if(!current())return;state.recruitPage={id,at:to,...(id==="maid"?{version:2}:{})};persist();render();
    host.querySelector('[data-read="next"],[data-read="finish"]')?.focus({preventScroll:true});
  },()=>{if(current())choose(0)});
}
function recruitArtwork(id,month){
  return path=>id==="maid"&&path===recruitCast.ciel
    ? (ageAt(month,28)>=12?recruitCast.ciel12:ageAt(month,28)>=11?recruitCast.ciel11:recruitCast.ciel)
    : path;
}
function openRecruitMemory(id){
  if(!Object.hasOwn(recruitScenes,id))return;stopRecruitAuto();
  const dlg=document.createElement("dialog");dlg.className="recruit-memory";dlg.setAttribute("aria-label",recruitScenes[id].name+" 영입 회상");
  dlg.innerHTML='<button class="memory-close" type="button">닫기</button><div class="recruit-host"></div>';
  document.body.append(dlg);dlg.addEventListener("close",()=>{stopRecruitAuto();dlg.remove()},{once:true});
  dlg.addEventListener("keydown",e=>{if(e.key==="Escape")e.stopPropagation()});dlg.querySelector(".memory-close").onclick=()=>dlg.close();
  const month=state.events.find(entry=>entry.id===id)?.month||state.month;
  const draw=at=>{drawRecruitReader(dlg.querySelector(".recruit-host"),id,at,recruitArtwork(id,month),true,draw,()=>dlg.close());};
  draw(0);dlg.showModal();
}
