"use strict";

const recruitArt={
  lab:{bg:"assets/prologue/cell.webp",crop:[0,0,221,145],tone:"cold"},
  dark:{bg:"assets/prologue/cell.webp",crop:[0,0,185,115],tone:"blackout"},
  night:{bg:"assets/room-garden.webp",tone:"night"},
  library:{bg:"assets/room-library.webp"},street:{bg:"assets/room-street.webp",tone:"night"},
  parlour:{bg:"assets/room-ballroom.webp"},study:{bg:"assets/manor.webp"}
};
const recruitCast={
  ciel:"assets/ciel.png",ciel11:"assets/ciel-11.webp",seb:"assets/sebastian.webp",
  finny:"assets/npc-finny.webp",mey:"assets/npc-mey.webp"
};
// Speakers before the naming scene use the boy's number. His gardener portrait appears only at the manor.
const recruitScenes={
  gardener:{name:"피니안",title:"번호 대신 이름을",result:"피니안이 팬텀하이브가의 정원사가 되었다.",scenes:[
    {title:"연구소",art:"lab",lines:[
      ["연구원","여긴 끝났어. 기록부터 없애!"],["다른 연구원","아이들은요?"],["연구원","실험체도 남겨 둘 수 없어. 서둘러!"],
      ["S-012","위가 시끄럽다. 옆에 앉아 있던 아이가 먼저 고개를 들었다."]]},
    {title:"선생님",art:"dark",lines:[
      ["아이","선생님?"],["S-012","문이 열렸다. 묻고 싶은 게 있었는데, 바로 옆에서 소리가 났다."],
      ["S-012","방금까지 내 옆에 앉아 있었잖아. 선생님, 왜……?"],["S-012","정신을 차렸을 때 나는 맨발로 달리고 있었다. 사다리 위의 뚜껑을 밀었다."]]},
    {title:"달빛 아래",art:"night",cast:["ciel","seb"],lines:[
      ["S-012","밖이었다. 하늘에 둥근 빛이 떠 있었다. 바로 앞에 두 사람이 서 있었다."],["S-012","으아아……!"],
      ["세바스찬","도련님, 제 뒤로."],["시엘","잠깐, 세바스찬."],["시엘","네 이름은?"],["피니안의 회상","그때는 무슨 말인지 몰랐다. 내게 이름을 물은 사람은 도련님이 처음이었다."]]},
    {title:"그 뒤, 저택의 서재",art:"library",cast:["finny","ciel"],lines:[
      ["피니안의 회상","머리카락이 이만큼 자랐을 때였다. 도련님이 책 한 권을 꺼내셨다."],["시엘","너한테 이름을 하나 지어 주겠어."],
      ["소년","이름?"],["시엘","언제까지고 널 피험자 12번이라 부를 순 없잖아. 금발이 제법 근사하게 자랐군."]]},
    {title:"금발의 영웅",art:"library",cast:["finny","ciel"],lines:[
      ["시엘","‘핀’. 옛말로 금발을 뜻하지. 여기 나오는 영웅도 그 머리 때문에 그렇게 불렸어."],["소년","그 책에 나처럼 머리 노란 사람이 있어?"],
      ["시엘","그래. 그래서 네 이름은 피니언이다."]]},
    {title:"세바스찬의 한마디",art:"library",cast:["ciel","seb"],lines:[
      ["세바스찬","꽤 거창한 이름을 골라 주셨군요."],["세바스찬","제 경우처럼 개 이름을 물려받는 것보다는 낫겠습니다만."]]},
    {title:"소년의 책",art:"library",cast:["finny","ciel"],lines:[
      ["시엘","이 책은 네 거야. 글자를 익히면 네 이름이 나온 대목을 직접 읽어 봐. 알았지, 피니언?"],["피니안","응!"],
      ["피니안의 회상","나한테 준 첫 책이었다. 꼭 안았더니 팔 안에서 표지가 우그러졌다."]]},
    {title:"저택의 새 사용인",art:"library",cast:["finny","seb"],lines:[
      ["세바스찬","이제야 표정이 풀리는군요."],["세바스찬","그럼 그 책을 조금만 놓아 주시겠습니까. 말씨도, 힘을 쓰는 법도 차차 익히셔야겠군요."]]}
  ]},
  maid:{name:"메이린",title:"저택에서 일하겠나",result:"메이린이 시엘의 제안을 받아들여 저택의 메이드가 되었다.",scenes:[
    {title:"팬텀하이브 저택",art:"study",cast:["ciel11","seb"],lines:[
      ["시엘","……방금 무슨 소리지?"],["세바스찬","도련님을 노린 자가 있는 모양입니다."],["메이린의 회상","청방에서 내게 맡긴 표적은 팬텀하이브가의 주인이었다. 그날, 그 집 집사가 나를 붙잡았다."]]},
    {title:"뜻밖의 빈자리",art:"library",cast:["ciel11","seb"],lines:[
      ["시엘","나를 죽이러 온 사람을 우리 집에 들이겠다고?"],["세바스찬","예. 저택을 지킬 솜씨를 가진 사람을 찾고 계셨잖습니까. 마침 메이드 자리도 비었지요."],
      ["메이린의 회상","나를 붙잡은 집사가 내 일자리를 의논하고 있었다. 그것도 내가 노렸던 사람 앞에서."]]},
    {title:"저택의 식탁",art:"parlour",cast:["ciel11"],lines:[
      ["메이린의 회상","식사를 마치자 집사가 차를 따랐다. 어린 주인이 내 쪽을 보았다."],
      ["시엘","여기서 내 메이드로 일하겠나? 아니면 계속 청방을 피해 다닐 셈이야?"],["메이린","……저는 메이드 일을 해 본 적이 없습니다."]]},
    {title:"메이린의 대답",art:"parlour",cast:["seb","ciel11"],lines:[
      ["세바스찬","저 역시 처음부터 집사였던 것은 아닙니다. 일을 배울 기회라면 여기 있지요."],["메이린","제가 여기서 일해도 되는 거라면…… 하겠습니다."]]},
    {title:"팬텀하이브가의 메이드",art:"study",cast:["mey"],lines:[
      ["메이린의 회상","그날 저택에 들어올 때의 나는 청방의 저격수였다. 내 발로 그 집에 남겠다고 대답한 뒤에야, 나는 팬텀하이브가의 메이드가 됐다."]]}
  ]}
};
for(const book of Object.values(recruitScenes)){
  book.lines=book.scenes.flatMap((scene,i)=>scene.lines.map(([speaker,text])=>({scene,i,speaker,text})));
}
function pageAt(id,at){return Number.isInteger(at)?Math.min(Math.max(0,at),recruitScenes[id].lines.length-1):0;}
function recruitPage(id){return pageAt(id,state.recruitPage?.id===id?state.recruitPage.at:0);}
function recruitMarkup(id,at,file=x=>x,readOnly=false,auto=false){
  const book=recruitScenes[id],{scene,speaker,text}=book.lines[at],art=recruitArt[scene.art],bg=file(art.bg),last=at===book.lines.length-1;
  const still=art.crop?'<svg class="recruit-still" viewBox="'+art.crop.join(" ")+'" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><image width="680" height="380" href="'+bg+'"/></svg>':'<img class="recruit-still" alt="" src="'+bg+'">';
  const names={ciel:"시엘",ciel11:"시엘",seb:"세바스찬",finny:"피니안",mey:"메이린"};
  const cast=(scene.cast||[]).map((person,i)=>'<img class="recruit-actor pos-'+i+(speaker===names[person]?' speaking':'')+'" src="'+file(recruitCast[person])+'" alt="'+names[person]+'">').join("");
  return '<article class="recruit-reader '+(art.tone||'')+'" data-book="'+id+'" data-leaf="'+at+'">'+still+'<div class="recruit-cast">'+cast+'</div><div class="opening-mat recruit-mat"><header class="opening-top"><button type="button" data-read="previous" '+(at===0?'disabled':'')+'>이전</button><button type="button" data-read="auto" aria-pressed="'+auto+'">'+(auto?'자동 멈춤':'자동 재생')+'</button></header><div class="opening-transcript recruit-transcript"><div class="opening-caption"><small>'+book.name+' 영입</small><span>'+scene.title+'</span></div><div class="opening-voice" aria-live="polite" aria-atomic="true"><b>'+speaker+'</b><p>'+text+'</p></div><div class="opening-controls"><small>'+(at+1)+' / '+book.lines.length+'</small><button type="button" data-read="'+(last?'finish':'next')+'">'+(last?(readOnly?'회상 마치기':'영입 기록하기'):'다음 ▸')+'</button></div></div></div></article>';
}
let recruitTimer=0,recruitAuto=false;
function stopRecruitAuto(){clearTimeout(recruitTimer);recruitTimer=0;recruitAuto=false;}
function drawRecruitReader(host,id,at,file,readOnly,onPage,onFinish){
  clearTimeout(recruitTimer);if(at===recruitScenes[id].lines.length-1)stopRecruitAuto();host.innerHTML=recruitMarkup(id,at,file,readOnly,recruitAuto);
  const node=host.querySelector(".recruit-reader"),last=at===recruitScenes[id].lines.length-1;
  function step(to){
    if(!node.isConnected)return;
    clearTimeout(recruitTimer);onPage(to);
  }
  function arm(){
    if(!recruitAuto||last)return;
    const delay=Math.min(6200,1700+recruitScenes[id].lines[at].text.length*90);
    recruitTimer=setTimeout(()=>{if(node.isConnected&&!document.hidden)step(at+1);else stopRecruitAuto()},delay);
  }
  node.addEventListener("click",e=>{
    const control=e.target.closest("[data-read]");
    if(control?.disabled||window.getSelection()?.toString())return;
    const read=control?.dataset.read||(!last?"next":"");
    if(!read)return;e.stopPropagation();
    if(read==="auto"){if(recruitAuto)stopRecruitAuto();else{recruitAuto=true;arm()}control.textContent=recruitAuto?"자동 멈춤":"자동 재생";control.setAttribute("aria-pressed",String(recruitAuto));return;}
    stopRecruitAuto();
    if(read==="previous"&&at>0)step(at-1);
    if(read==="next"&&!last)step(at+1);
    if(read==="finish"&&last)onFinish();
  });
  if(last)stopRecruitAuto();else arm();
}
function showMonthlyRecruit(host,event){
  const id=event.id,at=recruitPage(id);
  const current=()=>tab==="plan"&&["event","slotEvent"].includes(state.phase)&&state.pending===id&&recruitPage(id)===at;
  host.hidden=false;drawRecruitReader(host,id,at,x=>x,false,to=>{
    if(!current())return;state.recruitPage={id,at:to};persist();render();
    host.querySelector('[data-read="next"],[data-read="finish"]')?.focus({preventScroll:true});
  },()=>{if(current())choose(0)});
}
function openRecruitMemory(id){
  if(!Object.hasOwn(recruitScenes,id))return;stopRecruitAuto();
  const dlg=document.createElement("dialog");dlg.className="recruit-memory";dlg.setAttribute("aria-label",recruitScenes[id].name+" 영입 회상");
  dlg.innerHTML='<button class="memory-close" type="button">닫기</button><div class="recruit-host"></div>';
  document.body.append(dlg);dlg.addEventListener("close",()=>{stopRecruitAuto();dlg.remove()},{once:true});
  dlg.addEventListener("keydown",e=>{if(e.key==="Escape")e.stopPropagation()});dlg.querySelector(".memory-close").onclick=()=>dlg.close();
  const draw=at=>{drawRecruitReader(dlg.querySelector(".recruit-host"),id,at,x=>x,true,draw,()=>dlg.close());};
  draw(0);dlg.showModal();
}
